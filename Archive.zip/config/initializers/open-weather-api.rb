# OpenWeatherAPI.configure do |config|
#   # API key
#   config.api_key = "62bfa8521c1ad8c8e4c86669209ee8d0"

#   # Optionals
#   config.default_language = 'en'     # 'en' by default
#   config.default_country_code = 'en' # nil by default (ISO 3166-1 alfa2)
#   config.default_units = 'imperial	'    # 'metric' by default
# end