Gibbon::Request.api_key = "3f1699f830b3c1fcec92e0a586965c2e-us12"
Gibbon::Request.timeout = 15
Gibbon::Request.open_timeout = 15
Gibbon::Request.symbolize_keys = true
Gibbon::Request.debug = false